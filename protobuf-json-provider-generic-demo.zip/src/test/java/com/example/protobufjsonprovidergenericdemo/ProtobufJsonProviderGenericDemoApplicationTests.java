package com.example.protobufjsonprovidergenericdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProtobufJsonProviderGenericDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
