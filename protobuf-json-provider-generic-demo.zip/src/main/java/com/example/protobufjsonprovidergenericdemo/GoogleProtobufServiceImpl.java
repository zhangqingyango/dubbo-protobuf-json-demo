package com.example.protobufjsonprovidergenericdemo;


import org.apache.dubbo.config.annotation.DubboService;
import org.apache.dubbo.sample.protobuf.GoogleProtobufBasic;
import org.apache.dubbo.sample.protobuf.GoogleProtobufService;

@DubboService
public class GoogleProtobufServiceImpl implements GoogleProtobufService {
    @Override
    public GoogleProtobufBasic.GooglePBResponseType callGoogleProtobuf(GoogleProtobufBasic.GooglePBRequestType googlePBRequestType) {
        return GoogleProtobufBasic.GooglePBResponseType.newBuilder()
                .setFloat(123)
                .build();
    }
}
