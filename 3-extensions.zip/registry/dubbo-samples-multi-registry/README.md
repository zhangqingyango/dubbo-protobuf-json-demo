## [多注册中心](http://dubbo.apache.org/#!/docs/user/demos/multi-registry.md?lang=zh-cn)
Dubbo 支持同一服务向多注册中心同时注册，或者不同服务分别注册到不同的注册中心上去，甚至可以同时引用注册在不同注册中心上的同名服务。另外，注册中心是支持自定义扩展的。


